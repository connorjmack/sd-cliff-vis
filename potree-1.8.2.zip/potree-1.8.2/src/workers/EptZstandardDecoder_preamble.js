window = { };
document = { };