// importScripts('/libs/ept/ParseBuffer.js');
onmessage = function(event) {
	parseEpt(event);
}

