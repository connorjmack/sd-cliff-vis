

//import "../../libs/plasio/workers/laz-perf.js";
import {Module} from "../../libs/plasio/workers/laz-loader-worker.js";