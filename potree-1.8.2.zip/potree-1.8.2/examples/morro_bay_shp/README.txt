Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


Dieses Esri shapefile wurde erzeugt am: Tue Jun 13 12:40:57 UTC 2017
GPS Rechteck Koordinaten (lng,lat): -120.884,35.36 x -120.821,35.392
Script URL: https://extract.bbbike.org/?sw_lng=-120.884&sw_lat=35.36&ne_lng=-120.821&ne_lat=35.392&format=shp.zip&city=Morro%20Bay&lang=de
Name des Gebietes: Morro Bay

Spenden sind willkommen! Du kannst uns via PayPal, Flattr oder Bankueberweisung
unterstuetzen: https://www.bbbike.org/community.de.html

Danke, Wolfram Schneider

--
Dein Fahrrad-Routenplaner: https://www.BBBike.org
BBBike Map Compare: https://bbbike.org/mc
